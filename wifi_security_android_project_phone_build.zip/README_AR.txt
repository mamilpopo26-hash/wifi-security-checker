مشروع تطبيق فاحص أمان Wi-Fi لنظام Android

مهم:
- هذه ملفات مشروع Android Studio، وليست ملف APK جاهزاً.
- لا يمكن إنشاء APK في بيئة إعداد هذه الحزمة لعدم توفر Android SDK وأدوات بناء Android.
- التطبيق يقيّم كلمة المرور التي يدخلها مسؤول الشبكة محلياً. لا يخترق الشبكات ولا يستخرج كلمات المرور تلقائياً ولا يتصل بالراوتر.

طريقة إنشاء APK:
1) ثبّت Android Studio على الكمبيوتر.
2) افتح مجلد WifiSecurityChecker في Android Studio.
3) انتظر اكتمال Gradle Sync وثبّت SDK إذا طلب البرنامج ذلك.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) سيظهر ملف APK داخل app/build/outputs/apk/debug/.

للتثبيت:
- انقل APK إلى هاتف Android.
- افتحه واسمح بالتثبيت من هذا المصدر إذا طلب الهاتف ذلك.

المتطلبات:
- Android Studio حديث.
- Android SDK 35.
- Java 17 (عادةً يتولى Android Studio إدارته).
